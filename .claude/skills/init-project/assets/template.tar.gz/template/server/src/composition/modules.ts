/**
 * 模块装配 —— 把仓储、Service、路由依赖组装起来。
 *
 * 干什么: 每个业务模块一个 buildXxxModule(ctx) 函数,返回它的路由依赖。
 *
 * 解决什么问题:
 *   曾见过的一个项目的 main.ts 有 **1173 行**(300 行 import + 665 行连续的 new),
 *   一个函数里塞了 12 个域的装配。它自定的"装配 >200 行才考虑拆"的触发条件
 *   用了个 AND 把自己豁免掉了,实际早已 5 倍超标。
 *
 *   更直接的代价是**测试**: 它的 tasks.routes.test.ts 开头 import 了 24 个 UseCase,
 *   只为在 beforeEach 里把装配逻辑重抄一遍。装配改一次,要同步改 N 个测试文件。
 *
 *   拆成 buildXxxModule 之后,main.ts 和测试**调用的是同一个函数**,装配只有一份真相。
 *   加一个业务模块也不需要动 main.ts。
 */

import { AuthService } from '../modules/identity/application/auth.service.js';
import { RoleService } from '../modules/identity/application/role.service.js';
import { UserService } from '../modules/identity/application/user.service.js';
import { config } from '../platform/config/index.js';
import { buildRepos } from './repos.js';
import { ScryptPasswordHasher } from '../modules/identity/infra/scrypt-password-hasher.js';
import { Hs256TokenSigner } from '../modules/identity/infra/hs256-token-signer.js';
import type { AppDeps } from './app.js';
import type { AppContext } from './context.js';

/**
 * 组装全部模块,产出 buildApp 需要的依赖。
 *
 * 新增业务模块时改这里的两处:建 Service、填进返回值。
 */
export const buildModules = async (
  ctx: AppContext,
): Promise<Omit<AppDeps, 'version' | 'startedAt'>> => {
  const repos = buildRepos(ctx.prisma);
  const hasher = new ScryptPasswordHasher();
  
  // JWT 签发器。密钥与有效期都来自 config,时钟注入 —— 测试要能把"现在"固定住。
  const signer = new Hs256TokenSigner({
    secret: config.jwtSecret,
    ttlSeconds: config.jwtTtlSeconds,
    now: ctx.clock,
  });

  const authService = new AuthService({
    userRepo: repos.user,
    hasher,
    signer,
    ids: ctx.ids,
    clock: ctx.clock,
    logger: ctx.logger.child({ module: 'auth' }),
  });

  const userService = new UserService({
    userRepo: repos.user,
    roleRepo: repos.role,
    hasher,
    uow: ctx.uow,
    ids: ctx.ids,
    clock: ctx.clock,
    logger: ctx.logger.child({ module: 'user' }),
  });

  const roleService = new RoleService({
    roleRepo: repos.role,
    userRepo: repos.user,
    ids: ctx.ids,
    clock: ctx.clock,
    logger: ctx.logger.child({ module: 'role' }),
  });


  return {
    auth: {
      service: authService,
    },
    user: { service: userService },
    role: { service: roleService },
    logger: ctx.logger,
    // 健康检查的真探活。用 $queryRaw 而不是 count() ——
    // SELECT 1 不碰任何表,库结构变了也不会影响健康检查。
    pingDb: async (): Promise<boolean> => {
      try {
        await ctx.prisma.$queryRawUnsafe('SELECT 1');
        return true;
      } catch (e) {
        ctx.logger.error('数据库探活失败', { err: e });
        return false;
      }
    },
    bodyLimitBytes: config.bodyLimitBytes,
    loginRateLimit: {
      limit: config.loginRateLimit,
      windowMs: config.loginRateWindowMs,
      clock: ctx.clock,
    },
    clock: ctx.clock,
  };
};
